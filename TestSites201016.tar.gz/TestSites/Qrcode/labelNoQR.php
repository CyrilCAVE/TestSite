<!DOCTYPE html>
<html lang="en">

  					<img src="/TestSites/Qrcode/1106.png" alt="Smiley face" height="42" width="42">
	<hr>
 					<img src="/TestSites/Qrcode/1106.png" alt="Smiley face" height="80" width="80">
	<hr>
 					<img src="/TestSites/Qrcode/1106.png" alt="Smiley face" height="160" width="160">
	<hr>
 					<img src="/TestSites/Qrcode/1106.png" alt="Smiley face" height="320" width="320">
</html>
