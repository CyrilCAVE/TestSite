<!DOCTYPE html>
	<html lang="en">
		<body>
               <p>
                                INESO:INEPL-R01-02-868:0072FF001F17<br>
    <iframe src="http://dedicated.inesocompany.com:7670/TestSites/Logo/QrcodeLabel_868_28-09-2016/0072FF001F17.png" width="540" height="400" scrolling="no" frameBorder="0" onmouseover="afficher()" text-align="center" ></iframe>
                                INESO:INEPL-R01-02-868:0072FF001F18<br>
    <iframe src="http://dedicated.inesocompany.com:7670/TestSites/Logo/QrcodeLabel_868_28-09-2016/0072FF001F18.png" width="540" height="400" scrolling="no" frameBorder="0" onmouseover="afficher()" text-align="center" ></iframe>
                                INESO:INEPL-R01-02-868:0072FF001F19<br>
    <iframe src="http://dedicated.inesocompany.com:7670/TestSites/Logo/QrcodeLabel_868_28-09-2016/0072FF001F19.png" width="540" height="400" scrolling="no" frameBorder="0" onmouseover="afficher()" text-align="center" ></iframe>
                                INESO:INEPL-R01-02-868:0072FF001F20<br>
    <iframe src="http://dedicated.inesocompany.com:7670/TestSites/Logo/QrcodeLabel_868_28-09-2016/0072FF001F20.png" width="540" height="400" scrolling="no" frameBorder="0" onmouseover="afficher()" text-align="center" ></iframe>
                                INESO:INEPL-R01-02-868:0072FF001F1A<br>
    <iframe src="http://dedicated.inesocompany.com:7670/TestSites/Logo/QrcodeLabel_868_28-09-2016/0072FF001F1A.png" width="540" height="400" scrolling="no" frameBorder="0" onmouseover="afficher()" text-align="center" ></iframe>
                                INESO:INEPL-R01-02-868:0072FF001F1B<br>
    <iframe src="http://dedicated.inesocompany.com:7670/TestSites/Logo/QrcodeLabel_868_28-09-2016/0072FF001F1B.png" width="540" height="400" scrolling="no" frameBorder="0" onmouseover="afficher()" text-align="center" ></iframe>
                                INESO:INEPL-R01-02-868:0072FF001F1C<br>
    <iframe src="http://dedicated.inesocompany.com:7670/TestSites/Logo/QrcodeLabel_868_28-09-2016/0072FF001F1C.png" width="540" height="400" scrolling="no" frameBorder="0" onmouseover="afficher()" text-align="center" ></iframe>
                                INESO:INEPL-R01-02-868:0072FF001F1D<br>
    <iframe src="http://dedicated.inesocompany.com:7670/TestSites/Logo/QrcodeLabel_868_28-09-2016/0072FF001F1D.png" width="540" height="400" scrolling="no" frameBorder="0" onmouseover="afficher()" text-align="center" ></iframe>
                                INESO:INEPL-R01-02-868:0072FF001F1E<br>
    <iframe src="http://dedicated.inesocompany.com:7670/TestSites/Logo/QrcodeLabel_868_28-09-2016/0072FF001F1E.png" width="540" height="400" scrolling="no" frameBorder="0" onmouseover="afficher()" text-align="center" ></iframe>
                                INESO:INEPL-R01-02-868:0072FF001F1F<br>
    <iframe src="http://dedicated.inesocompany.com:7670/TestSites/Logo/QrcodeLabel_868_28-09-2016/0072FF001F1F.png" width="540" height="400" scrolling="no" frameBorder="0" onmouseover="afficher()" text-align="center" ></iframe>
                                INESO:INEPL-R01-02-868:0072FF001F17<br>
                                INESO:INEPL-R01-02-868:0072FF001106<br>
                                INESO:INEPL-R01-02-868:0072FF001106<br>
                                INESO:INEPL-R01-02-868:0072FF001106<br>
                                INESO:INEPL-R01-02-868:0072FF001107<br>
                                INESO:INEPL-R01-02-868:0072FF001F0A<br>
                                INESO:INEPL-R01-02-868:0072FF001F0B<br>
                                INESO:INEPL-R01-02-868:0072FF001F0C<br>
                                INESO:INEPL-R01-02-868:0072FF001F0D<br>
                                INESO:INEPL-R01-02-868:0072FF001F0E<br>
                                INESO:INEPL-R01-02-868:0072FF001F0F<br>
                                INESO:INEPL-R01-02-868:0072FF001F0H<br>
                                </p>
		</body>
</html>
