<!DOCTYPE html>
<html lang="en">
<head>
                <META CHARSET="UTF-8">
                <!-- css-->
		<link rel="stylesheet" type="text/css" href="TestSites/style.css">
		<base target="_parent">
</head>

<body>
	<div align="center" scroll="auto"><?php require_once('../Menu/label.php'); ?></div>

		<h2 align="center"> Qrcode Devices : <h2>
	<div align="center">

	<table cellspacing="100%" style="table-layout: fixed">
		<col style="width: 20%:">
		<col style="width: 20%:">
		<col style="width: 20%:">
		<col style="width: 20%:">
		<col style="width: 20%:">
	<tbody>
		<td><p>Format 42<br>
  		<img src="/TestSites/Qrcode/1106.png" alt="Smiley face" height="42" width="42">
		</td><td><p>Format 85 <br> label 20x20 mm :<br>
  		<img src="/TestSites/Qrcode/1106.png" alt="Smiley face" height="85" width="85">
		</td><td><p>Format 110<p><br> 
 		<img src="/TestSites/Qrcode/1106.png" alt="Smiley face" height="110" width="110">
		</td><td><p>Format 160<p><br>
		<img src="/TestSites/Qrcode/1106.png" alt="Smiley face" height="160" width="160">
		</td><td><p>Format 320<p><br>
 		<img src="/TestSites/Qrcode/1106.png" alt="Smiley face" height="320" width="320">
		</td>
	</tbody>
	</table>
	<div>
		<table test-align="center"  style="table-layout: fixed:" >
			<col style="width: 30%:"/>
			<col style="width: 5%:"/>
			<col style="width: 30%:"/>
			<col style="width: 5%:"/>
			<col style="width: 30%:"/>
			<tbody>
				<th>433 Mhz</th>
				<th> | </th>
				<th> 868 Mhz</th>
				<th> | </th>
				<th>915 Mhz</th>
			<tr></tr>
			<td><hr>
					INESO:INEPL-R01-02-433:0072FF001F01</br>
					INESO:INEPL-R01-02-433:0072FF001F02</br>
					INESO:INEPL-R01-02-433:0072FF001F03</br>
					INESO:INEPL-R01-02-433:0072FF001F04</br>
					INESO:INEPL-R01-02-433:0072FF001F05</br>
			</td>
				<td>
				|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|
				</td>
			<td>	<div align="center">
    		<iframe src="http://dedicated.inesocompany.com:7670/TestSites/Menu/date_heure.html" width="540" height="40" scrolling="auto" frameBorder="0" onmouseover="afficher()" text-align="center" ></iframe><hr>
    		<iframe src="http://dedicated.inesocompany.com:7670/TestSites/Qrcode/List_Qrcode.php" width="600" height="400" scrolling="auto" frameBorder="0" onmouseover="afficher()" text-align="center" ></iframe>
			</td><td>
				|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|<br>|
			</td>
				<td>
					INESO:INEPL-R01-02-915:0072FF001331</br>
					INESO:INEPL-R01-02-915:0072FF0012A8</br>
					INESO:INEPL-R01-02-915:0072FF001F10</br>
					INESO:INEPL-R01-02-915:0072FF001F11</br>
					INESO:INEPL-R01-02-915:0072FF001F12</br>
					INESO:INEPL-R01-02-915:0072FF001F13</br>
				</td>
			</tbody>
		</table>
	</div>
<br><hr><br>
	<div><p class="nimbus"> Test jeu d'essai- exemple de radio - code pour faire un arbre de choix de solution é à /c - méthode pour ZP-L
	<form method="post" action="traitement.php">
   		<p>
       		Veuillez indiquer la fréquence de la boite :<br />
       		<input type="radio" name="frequence" value="433" id="433" /> <label for="433">433MHz</label><br />
       		<input type="radio" name="frequence" value="868" id="868" /> <label for="868">868MHz</label><br />
       		<input type="radio" name="frequence" value="915" id="915" /> <label for="915">915MHz</label><br />
       		<input type="radio" name="age" value="plus40" id="plus40" /> <label for="plus40">Autre ?!</label>
   		</p>
	</form>

        <form method="post" action="traitement.php">
                <p>
                Veuillez indiquer la fréquence de la boite :<br />
                <input type="radio" name="frequence" value="433" id="433" /> <label for="433">433MHz</label><br />
                <input type="radio" name="frequence" value="868" id="868" /> <label for="868">868MHz</label><br />
                <input type="radio" name="frequence" value="915" id="915" /> <label for="915">915MHz</label><br />
                <input type="radio" name="age" value="plus40" id="plus40" /> <label for="plus40">Autre ?!</label>
                </p>
        </form>
<?php
	echo  'fin de document';
	echo '<hr>';
 ?>

                                <?php
                                        echo " <h3>lecture de l image :</h3>";
                                        $read = '/var/www/TestSites/Qrcode/1106.png';
                                                $im = imagecreatefrompng($read);
                                                header('Content-Type: image/png');
                                                imagepng($im);
                                                imagedestroy($im);
                                ?>
