<!DOCTYPE html>
<html lang="en">
        <head>
                <META CHARSET="UTF-8">
                <!-- css-->                <link rel="stylesheet" type="text/css" href="http://dedicated.inesocompany.com:7670/TestSites/style.css">
	        <title>Sites.html</title>
        </head>
 <body>
  <header>
	 <iframe src="/TestSites/Menu/banniere.php" width=100% height="150" scrolling="no" frameBorder="0"></iframe>

	<h2>TESTBENCH & CUSTOMER PLATFORMS</h2>

	<p> Login <?php echo $_POST["Login"]; ?> Password <?php echo $_POST["motdepasse"]; ?> <b> <?php echo $_POST["civil"]; ?>  <?php echo " ".$_POST["nom"]; ?>
		 <br>Welcome <?php echo $_POST["prenom"]; ?> !!!</b>
		 Your email <?php echo $_POST["email"]; ?>
		 Phone <?php echo $_POST["phone"]; ?><br>
		 time_session_start <?php echo $_POST["el_session_time"]; ?> <br> <br>

		<script>
			function maPosition(position) {
	 		var infopos = "Position déterminée :\n";
	  		infopos += "Latitude : "+position.coords.latitude +"\n";
	  		infopos += "Longitude: "+position.coords.longitude+"\n";
	  		infopos += "Altitude : "+position.coords.altitude +"\n";
	  		document.getElementById("infoposition").innerHTML = infopos;
			}
			if (navigator.geolocation) {
  			navigator.geolocation.getCurrentPosition(maPosition);
    			alert("Bravo ! Votre navigateur prend en compte la géolocalisation HTML5");
			}
			else
			alert("Votre navigateur ne prend pas en compte la géolocalisation HTML5");
		</script>
		<?php
//			require '/TestSites/Menu/solarHour.php'; //require('/TestSites/Menu/solarHour.php');
//		 ?>
			<!-- L'heure du soleil -->
<br>		<?php
			/* Calcule l'heure du lever du soleil pour Lisbonne, Portugal
			Latitude: 38.4 North	 Longitude: 9 West		Zenith ~= 90	offset: +1 GMT
			*/
			$latitude=38.4;$longitude=9;
			$utc=2; $zenith=90;
			echo "Horaires du soleil : ".'<br>'."Lever : ".date("D M d Y"). ', sunrise time : ' .date_sunrise(time(), SUNFUNCS_RET_STRING, $latitude, -$longitude, $zenith, $utc).'<br>';
			echo "Coucher : ".date("D M d Y"). ', sunset time : ' .date_sunset(time(), SUNFUNCS_RET_STRING, $latitude, -9, $zenith, $utc);
		?>
		<br><br>
	</p>
  </header>

    <fieldset> <legend>Please follow these links for each testbench you find element for configuration, interface and database.</legend>

	<div align="center">

		<details open><summary>TestBench</summary>
	       		<iframe src="http://dedicated.inesocompany.com:7670/TestSites/WebSites/Test/sitesTest1.php" width="100%" height="349" scrolling="auto" frameBorder="0"></iframe>
		</details>

		<details><summary>Customers</summary>
			<iframe src="http://dedicated.inesocompany.com:7670/TestSites/WebSites/CustomerV3/sitesCustomer.php" width="100%" height="410" scrolling="auto" frameBorder="0"></iframe>
		</details>

		<details><summary>Plateform (version 2)</summary>
			<iframe src="http://dedicated.inesocompany.com:7670/TestSites/WebSites/Customer/sitesCustomer.php" width="100%" height="410" scrolling="auto" frameBorder="0"></iframe>
		</details>
	</div>
   </fieldset>

  <footer>
  	 <iframe src="http://dedicated.inesocompany.com:7670/TestSites/Menu/footer.php" width="100%" height="60" scrolling="no" frameBorder="0"></iframe>
  </footer>
 </body>
</html>
