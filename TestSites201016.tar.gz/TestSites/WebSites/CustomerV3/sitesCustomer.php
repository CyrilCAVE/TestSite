<!DOCTYPE html>
<html lang="en">
<head>
                <META CHARSET="UTF-8">
                <!-- css-->
                <!--<link rel="stylesheet" type="text/css" href="TestSites/style.css">-->
		<base target="_blank">
</head>
<body>
    <div> <h2> CUSTOMER PLATFORMS : </h2>
	</div>	
   <div align="center">
	<table cellspacing=25%>
		<tr align="center" width="100%">
		               <td><form>
                                <button input type="submit"
                                        style="height:280px; width:280px;"
                                         formaction="/TestSites/WebSites/CustomerV3/supChina.html"
                                         title="To access to the customer side"><h3>SUP CHINA</h3>
                                         <img src="/TestSites/Logo/china_pin.jpg" /></button>
                                </form></td>
                               <td><form>
                                <button input type="submit"
                                        style="height:280px; width:280px;"
                                         formaction="/TestSites/WebSites/CustomerV3/supBolivia.html"
                                         title="To access to the customer side"><h3>SUP BOLIVIA</h3>
                                         <img src="/TestSites/Logo/bolivia.png" /></button>
                                </form></td>
                               <td><form>
                                <button input type="submit"
                                        style="height:280px; width:280px;"
                                        formaction="/TestSites/WebSites/CustomerV3/supSF.html"
	                                title="To check in Estelec Plateforme"><h3>SUP SAN FRANCISCO</h3><br>
                                        <img src="/TestSites/Logo/SanFrancisco.png" /></button>
                                </form></td>
                               <td><form>
                                <button input type="submit"
                                        style="height:280px; width:280px;"
                                        formaction="/TestSites/WebSites/CustomerV3/supOrleans.html"
                                        title="To find information about testing"><h3>SUP ORLEANS</h3><br>
                                        <img src="/TestSites/Logo/orleans.png" /></button>
                                </form></td>
                               <td><form>
                                <button input type="submit"
                                        style="height:280px; width:280px;"
                                        formaction="/TestSites/WebSites/CustomerV3/supChina.html"
                                        title="To find information about testing"><h2>SUP CHINA</h2><br>
                                        <img src="/TestSites/Logo/china.jpg" /></button>
                                </form></td>
		 </tr>
	</table>
   </div>
</body>
