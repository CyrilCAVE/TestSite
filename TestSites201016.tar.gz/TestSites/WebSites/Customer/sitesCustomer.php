<!DOCTYPE html>
<html lang="en">
<head>
                <META CHARSET="UTF-8">
                <!-- css-->
                <!--<link rel="stylesheet" type="text/css" href="TestSites/style.css">-->
		<base target="_blank">
</head>
<body>
    <div> <h2> CUSTOMER PLATFORMS (version 2): </h2>
	</div>	
   <div align="center">
	<table cellspacing=25%>
		<tr align="center" width="100%">
                               <td><form>
                                <button input type="submit"
                                        style="height:280px; width:280px;"
                                         formaction="/TestSites/WebSites/Customer/supfulham.html"
                                         title="To access to the customer side"><h3>Sup Fuhlam</h3>
                                         <img src="/TestSites/Logo/Fulham.jpg" /></button>
                                </form></td>
                               <td><form>
                                <button input type="submit"
                                        style="height:280px; width:280px;"
                                        formaction="/TestSites/WebSites/Customer/supcl.html"
	                                title="To check in Estelec Plateforme"><h2>SUP CL</h2><br>
                                        <img src="/TestSites/Logo/.png" /></button>
                                </form></td>
                               <td><form>
                                <button input type="submit"
                                        style="height:280px; width:280px;"
                                        formaction="/TestSites/WebSites/Customer/supasolution.html"
                                        title="To find information about testing"><h2>SUP A SOLUTION</h2><br>
                                        <img src="/TestSites/Logo/.png" /></button>
                                </form></td>
                               <td><form>
                                <button input type="submit"
                                        style="height:280px; width:280px;"
                                        formaction="/TestSites/WebSites/Customer/supdorlisheim.html"
                                        title="To find information about testing"><h2>SUP DORLISHEIM</h2><br>
                                        <img src="/TestSites/Logo/Dorlisheim.png" /></button>
                                </form></td>
		 </tr>
	</table>
   </div>
</body>
