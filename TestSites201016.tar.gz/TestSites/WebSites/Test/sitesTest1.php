<!DOCTYPE html>
<html lang="en">
<head>
                <META CHARSET="UTF-8">
                <!-- css-->
                <!--<link rel="stylesheet" type="text/css" href="TestSites/style.css">-->
		<base target="_blank">
</head>
<body>
   <div align="center">
	<table cellspacing=25%>
		<tr align="center" width="100">
                        <td>
				<form>
                                <button input type="submit"
                                        style="height:280px; width:280px;"
                                         formaction="/TestSites/WebSites/Test/supdemov3.html"
                                         title="To introduce the web site to manage the system in customer side"><h3>Sup test demo V3</h3>
                                         <img src="/TestSites/Logo/logo_ineso.gif" /></button>
                        	</form>
			</td>
                        <td><form>
                                <button input type="submit"
                                        style="height:280px; width:280px;"
                                        formaction="/TestSites/WebSites/Test/suptestV3.html"
	                                title="To check in Estelec Plateforme"><h2>Sup Test V3</h2><br>
                                        <img src="/TestSites/Logo/estelec.png" /></button>
                                </form>
			</td>
                        <td><form>
                                <button input type="submit"
                                        style="height:280px; width:280px;"
                                        formaction="/TestSites/WebSites/Test/supmayatest.html"
                                        title="To find information about testing"><h2>Sup Maya-Test V3</h2><br>
                                        <img src="/TestSites/Logo/logo-maya.png" /></button>
                                </form>
			</td>
                        <td>
				<form>
                                <button input type="submit"
                                        style="height:280px; width:280px;"
                                        formaction="/TestSites/WebSites/Test/supQualif.html"
                                        title="To find information about testing"><h2>Sup Qualification V3</h2><br>
                                        <img src="/TestSites/Logo/logo-maya.png" /></button>
                                </form>
			</td>
		 </tr>
	</table>
   </div>
</body>
