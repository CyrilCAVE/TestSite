<!DOCTYPE html>
<html lang="en">
        <head>
                <META CHARSET="UTF-8">
                <!-- css-->
		<link rel="stylesheet" type="text/css" href="/TestSites/style.css">
		<base target="_parent">
        </head>
	<body>
		<div align="center">
			 <h1>TEST PLATFORMS version 3 Mayanet</h1>
		<fieldset><legend>Choose one plateform</legend>
        		<table border="0" style="table-layout: fixed;">
                                        <col style="width: 33px;"/>
                                        <col style="width: 66px;"/>
                                        <col style="width: 100px;"/>
			<tbody>
				<tr>
                                        <td>    <form> <button input type="submit"
                                                        style="height:280px; width:280px; align:center;"
                                                        formaction="/TestSites/WebSites/Test/supmayatest.html"
                                                        title="To test developpement">
                                                        <h2>MAYA SupMayaTest</h2><br>
                                                        <img src="/TestSites/Logo/logo-maya.png" /></button>
                                                 </form>
                                        </td>
					<td>
						<form><button input type="submit"
                                        		style="height:280px; width:280px; align:center;"
                                         		formaction="/TestSites/WebSites/Test/supdemov3.html"
                                         		title="To show the software to customer">
							<h2>Sup Test Demo V3</h2>
                                        		<img src="/TestSites/Logo/logo-maya.png" /></button>
                                		</form>
					</td>
					<td>	<form><button input type="submit"
                                        		style="height:280px; width:280px; align:center;"
                                        		formaction="/TestSites/WebSites/Test/suptestv3.html"
                                        		title="To pratice testing before Production delivery">
							<h2>ESTELEC SupTestV3</h2><br>
                                        		<img src="/TestSites/Logo/estelec.png" /></button>
                                		</form>
					</td>
				</tr>
			</tbody>
			</table>
		</fieldset>
		</div>
	</body>
</html>

