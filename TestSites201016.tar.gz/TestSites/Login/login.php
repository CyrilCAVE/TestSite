<?php
// page1.php
      session_name(Standalone);
        session_start();
                echo '<h2>Welcome to page #1</h2>';
              echo 'Php is working and here is the session name is : '.session_name();
              echo '. The value is One if the session is started : '.session_start();
                $_SESSION['favcolor'] = 'green';
              echo '<br>'.'examples PHP session variable :'.'<br>'.'<li>The favorite color is : '.$_SESSION['favcolor'].'</li>';
                $_SESSION['society'] = 'Maya_Technologies';
              echo '<br>'.'<li>The company is : '.$_SESSION['society'].'</li>';
                $_SESSION['correspondant'] = 'Cyril CAVÉ';
              echo '<br>'." <li>My name is : ".$_SESSION['correspondant'].'</li>';
                $_SESSION['mail'] = 'cyril.cave@maya-technologies.com';
              echo  '<br>'."<li>My mail adresses is : ".$_SESSION['mail'].'</li>';
                $_SESSION['time'] = time();
              echo '<br>'."<li>The timestamp is : ".$_SESSION['time'].'</li>';
                $_SESSION['date'] = date("d-m-Y");
              echo '<br>'."<li>The date is : ".$_SESSION['date'].'</li>';

?>

<!DOCTYPE html>
<html lang="en">
 <head>
		<META CHARSET="UTF-8">
		<!-- css-->
		<link rel="stylesheet" type="text/css" href="/TestSites/style.css">
		<title>HelloINESOTeam</title>
</head>
 <body>
  <header>
               	<iframe src="http://dedicated.inesocompany.com:7670/TestSites/Menu/header.php" width="540" height="220" scrolling="no" frameBorder="0"></iframe>
               <h1>IDENITFY TO ACCESS</h1>
                <h3><iframe src="http://dedicated.inesocompany.com:7670/TestSites/Menu/date_heure.html" width="540" height="30" scrolling="no" frameBorder="0" onmouseover="afficher()" text-align="center" ></iframe>
  </header>
	<section>
		<table align="center" width="70%">
			<td>
				<fieldset><legend>Connect with your personal ID</legend>
                               		<form action="/TestSites/WebSites/sites.php" method="post">
                                                <br>
                                                <br>
                                                Login : <input id="Login" type="text" name="Login" value="rBarnevon" placeholder="Please, write your Login"/>
                                                Password : <input type="password" name="motdepasse" value="blablack" maxlength=8/></p>
                                                <p>     <button type="reset" value="reset">Clear All</button>
                                                        <button id="OpenWebSites1" type="submit" name="submit" value="Submit" >Submit</button></p>
                                	</form>
				</fieldset>
			</td>
			<td>
                       <details><summary>New Account</summary>
			<fieldset><legend>Create</legend>
                                <p><span onclick="this.parentElement.style.display='none'" class="w3-closebtn">close here</span>
                                <button onclick="this.parentElement.style.display='none'" class="w3-closebtn">X</button></p>
                                        <form action="http://dedicated.inesocompany.com:7670/TestSites/WebSites/sites.php" method="post">
                                        	<p> Mr. <input type="radio" name="civil" value="Mr." checked >
                                                 Mrs. <input type="radio" name="civil" value="Mrs." >
                                                 Miss. <input type="radio" name="civil" value="Miss." >

                                                <br>Name : <input id="Name" type="text" name="nom" value="" placeholder="Please, write your name"/>
                                                Surname : <input id="Surname" type="text" name="prenom" value="" placeholder="Please, write your surname"/>

                                                <br>Email : <input type="email" name="email" value="r.barnevon@gmail.com" autofocus placeholder="here, write your e-mail" />
                                                Phone number : <input type="tel" name="phone" value="06 69 69 69 69" autofocus placeholder="write your phone number" />
                                                <br>
                                                <br>
                                                Login : <input id="Login" type="text" name="Login" value="rBarneoud" placeholder="Please, write your Login"/>
                                                Password : <input type="password" name="motdepasse" value="blablack" maxlenght=8/></p>
 <br>
                        Element de session : <input type="text" name="el_session_time" value=<?php echo $_SESSION['time']; ?>  placehoder="this is an element of session, change it if you want"/>

                                                <p>
						<button type="reset" value="reset">Clear All</button>
                                                <button id="OpenWebSites1" type="submit" name="submit" value="Submit">Submit</button></p>
                                        </form>
                          </fieldset>
			</details>
			</td>
		</table>
	</section>

	<details><summary>testtool</summary>
                                <iframe src="http://dedicated.inesocompany.com:7670/TestSites/Menu/testTool.php" width="100%" height="340" scrolling="no" frameBorder="0"></iframe>
	</details>

   <footer>
		<h4 align="left"><a href="http://dedicated.inesocompany.com:7670" target="_self"><img src="/TestSites/Logo/home.gif" /></a><h4>
		 <?php require_once '/TestSites/Menu/footer.php';?>
                <iframe src="http://dedicated.inesocompany.com:7670/TestSites/Menu/footer.php" width="100%" height="60" scrolling="no" frameBorder="0"></iframe>
  </footer>
 </body>
</html>
