<html>
<head>
 <meta charset="UTF-8">
</head>
<body>
	<header>
		<h1>Changelog</h1>
	</header>


	<details open><summary><h2>To do list<h2></summary>
		<ol type="A">
		<li>Test Sheet :</li>
			<ol type="1">
			<li>Formulaire de création</li>
			<li>Editer une fdt </li>
			<ul>
			<li>Store in  data base</li>
				<ul type="a"><a href="http://www.w3schools.com/php/php_mysql_connect.asp">Lien base de données</a>
					<li>PDO</li>
					<li>Mysql</li>
					<li>XML</li>
				</ul>
			</ul>
		<li>Executer un test et creer un rapport du test en un document PDF</li>
		<li>Copie un test et creer un rapport du test en un document PDF</li>
		<li>Faire une regression d'un test, rejouer un test et creer un rapport du test en un document PDF</li>
		</ol>	<br>
	<li> Création d'une version : </li>
		<ol type="1">
		<li>Opération Mode  archivage to complete</li>
		<li>Règle de version</li>
		</ol>
	</ol>
		<br>
		<br>
***************************************************************************************************************************************************
</details><details open><summary><h2>Octobre 2016</h2></summary>

	<ul>
                <li>20/10/2016</li>
                        <ul>
			<li>Manifest testsite.appcache</li>
			<li>Create a version</li>
                                <ul><li> Ajout icone banniere</li>
                                </ul>
			<ul><li>Mode operatoire</li>
                                <ul><li> Archivage</li>
                        </ul>
                        </ul>
                        </ul>



		<li>19/10/2016</li>
			<ul><li>Create change log web site changeLog.php</li>
				<ul><li> Ajout icone banniere 	</li>
				</ul>
			</ul>
		<li>18/10/2016</li>
				<ul>
					<li>add login.php  and sites.php</Li>
					<ul>
						<li>  Variable Session</li>
						<li>  Ajout de variable du login</li>
					</ul>
					<li>Heure de lever du soleil en Php</Li>
					<li>Heure du coucher du soleil en Php</Li>

			<li>Fiche de test</li>
				<ul>
					<li>Creation du modele de Formulaire </li>
					<li>Creation de l'objet en javascript</li>
					<li>Creation de l'objet en Php</li>
					<li>Creation de l'objet en Javascript</li>
				</ul>
			</ul>
		<li>Semaine 41</li>
				<ul>
				<li>Page d'accueil</li>
				<ul>
					<li> la gestion de projet logiciel</li>
					<li> le management de la qualite</li>
					<li> le management de la certification</li>
					<li></li>
					<li></li>
				</ul>
			<li></li>

		</ul>
</details>
<details><summary><h2>Septembre 2016</h2></summary>
    <ul>
                        <li>Qrcode</li>
                        <ul><li>Release</li>
                                <ul>
					<li> Ajout icône banniere   </li>
				</ul>
                        </ul>

                        <li>Save</li>
                        <li>tree.txt</li>
                                <ul><li>Consultation de repertoire </li>
                                        <ul><li> parametrage de chemin</li>
                                        <ul><li> scan</li>
                       			</ul>

                		</ul>
		</ul>
</details>
<details><summary><h2>Aout 2016</h2></summary>
    <ul>
                        <li>Data Base</li>
                        <li>Ajout de l'heure</li>
                        <ul>
				<li>Heure du client en javascript</li>
				<li>Heure du client en PHP</li>
				<li>Systeme de rafraischissment des heures</li>
               		 </ul>
                        <li>MAP</li>
                                <ul><li>Google Map</li>
                                        <ul><li>element de comparaison</li>
					</ul>
				</ul>
	                </ul>
	</ul>
</details>
<details><summary><h2>Juillet 2016</h2></summary>
    <ul>
                        <li>Banniere</li>
                        <li>Footer</li>
                        <li>Lien vers Bugzilla</li>
                        <li>Lien vers TestLink</li>
                        </ul>

                </ul>

	</ul>
</details>


	<footer>
		<?php require '/TestSuite/Menu/footer.php' ?>
	</footer>
	</body>
</html>
