<html>
<body>
root@ServerGIT:/home/git/repositories/Ineso_StreetLight_Mayanet.git# git log --stat<br>
commit 2bff0eda4dd5a4999fe6281a495b4c260c59f425<br>
Author: Maya Technologies <francois.nacabal@maya-technologies.com><br>
Date:   Tue Aug 30 10:56:04 2016 +0200<br>
<br>
    fix<br>
<br>
 VERSION                                |   2 +-<br>
 _build/ineso-concentrator.tar.gz       | Bin 2038321 -> 2038328 bytes<br>
 _build/ineso-concentrator.tar.gz.md5   |   2 +-<br>
 _build/ineso-supervisor.tar.gz         | Bin 11773637 -> 11773672 bytes<br>
 _build/ineso-supervisor.tar.gz.md5     |   2 +-<br>
 _build/mayanet-concentrator.tar.gz     | Bin 37799033 -> 37798516 bytes<br>
 _build/mayanet-concentrator.tar.gz.md5 |   2 +-<br>
 concentrator/bin/mayanet_update        |   2 ++<br>
 doc/changelog.txt                      |   1 +<br>
 9 files changed, 7 insertions(+), 4 deletions(-)<br>
<br>
commit 1f8a0a9f6c98352bd6517a9c3b85ee6c134d4148<br>
Author: Maya Technologies <francois.nacabal@maya-technologies.com><br>
Date:   Mon Aug 29 17:00:41 2016 +0200<br>
<br>
    adjust store capacity<br>
<br>
 VERSION                                  |   2 +-<br>
 _build/ineso-concentrator.tar.gz         | Bin 2038331 -> 2038321 bytes<br>
 _build/ineso-supervisor.tar.gz           | Bin 11773600 -> 11773637 bytes<br>
 _build/mayanet-concentrator.tar.gz       | Bin 37798945 -> 37799033 bytes<br>
 concentrator/etc/kura/etc/snapshot_0.xml |   2 +-<br>
 doc/changelog.txt                        |   1 +<br>
 6 files changed, 3 insertions(+), 2 deletions(-)<br>
<br>
commit 637ad5da77d9d1f23ef75431b02e63fdcc81a778<br>
Merge: f98d4be 18a8632<br>
Author: mathias <mathias.billoir@gmail.com><br>
Date:   Fri Aug 26 11:42:28 2016 +0200<br>
<br>
    Merge branch 'master' of ssh://dedicated.inesocompany.com:221/Ineso_StreetLight_Mayanet<br>
<br>
commit f98d4be224813ad81e5bd9e7ffc1671baf5db667<br>
Author: root <root@inesodev2.com><br>
Date:   Fri Aug 26 11:29:23 2016 +0200<br>
<br>
    new release<br>
<br>
 VERSION                                      |   2 +-<br>
 _build/ineso-concentrator.tar.gz             | Bin 2038240 -> 2038228 bytes<br>
 _build/ineso-concentrator.tar.gz.md5         |   2 +-<br>
 _build/ineso-supervisor.tar.gz               | Bin 11774067 -> 11774068 bytes<br>
 _build/ineso-supervisor.tar.gz.md5           |   2 +-<br>
 _build/mayanet-concentrator.tar.gz           | Bin 37795475 -> 37795531 bytes<br>
 _build/mayanet-concentrator.tar.gz.md5       |   2 +-<br>
 concentrator/packages/ineso_gateway_osgi.dp  | Bin 2037703 -> 2037701 bytes<br>
 doc/changelog.txt                            |   2 ++<br>
 supervisor/etc/mysql/my.cnf                  |   3 ++-<br>
 supervisor/packages/ineso_supervisor_osgi.dp | Bin 9728214 -> 9728194 bytes<br>
 11 files changed, 8 insertions(+), 5 deletions(-)<br>
<br>
commit 18a8632677b9912377cb8fe41c078722b23264af<br>
Author: Maya Technologies <francois.nacabal@maya-technologies.com><br>
Date:   Tue Aug 9 16:43:20 2016 +0200<br>
<br>
</body>
</html>
