<html>
<body>
	<h3>commit df598f4684a6edacc26b2ee8cc750498e476ca89</h3><br>
Author: Maya Technologies <francois.nacabal@maya-technologies.com><br>
Date:   Tue Aug 30 10:59:11 2016 +0200<br>
<br>
    v2.1.58<br>
<br>
 _sources/meta-inesocompany/meta-ineso/recipes-ineso/mayanet/mayanet_2.1.57.bb | 4 ----<br>
 _sources/meta-inesocompany/meta-ineso/recipes-ineso/mayanet/mayanet_2.1.58.bb | 4 ++++<br>
 2 files changed, 4 insertions(+), 4 deletions(-)<br>
<br>
commit 870f06e62180ba33f767f56995ecb46205598eaf<br>
Author: Maya Technologies <francois.nacabal@maya-technologies.com><br>
Date:   Mon Aug 29 17:07:05 2016 +0200<br>
<br>
    2.1.57<br>
<br>
 _sources/meta-inesocompany/meta-ineso/recipes-ineso/mayanet/mayanet_2.1.54.bb | 4 ----<br>
 _sources/meta-inesocompany/meta-ineso/recipes-ineso/mayanet/mayanet_2.1.57.bb | 4 ++++<br>
 2 files changed, 4 insertions(+), 4 deletions(-)<br>
<br>
commit 68f69639835b708da09cbfd02a5ba52c3a046441<br>
Author: Maya Technologies <francois.nacabal@maya-technologies.com><br>
Date:   Fri Jul 29 10:39:50 2016 +0200<br>
<br>
    fix<br>
<br>
 _sources/meta-inesocompany/meta-ineso/recipes-ineso/mayanet/mayanet_2.1.42.bb | 4 ----<br>
 _sources/meta-inesocompany/meta-ineso/recipes-ineso/mayanet/mayanet_2.1.54.bb | 4 ++++<br>
 _sources/meta-intel                                                           | 2 +-<br>
 _sources/meta-openembedded                                                    | 2 +-<br>
 _sources/poky                                                                 | 2 +-<br>
 5 files changed, 7 insertions(+), 7 deletions(-)<br>
<br>
commit 0afa350c9ffa71b183cab13ca642228d010e35e2<br>
Author: Francois Muller <francois@concept-embarque.fr><br>
Date:   Wed Jul 13 11:34:14 2016 +0200<br>
<br>
    ineso-image-concentrator: Add SFTP capability<br>
<br>
 _sources/meta-inesocompany/meta-ineso/recipes-ineso/images/ineso-image-concentrator.bb | 1 +<br>
 1 file changed, 1 insertion(+)<br>
<br>
commit f8ee604ff3c91efc0dcdd6088d04b8a3511c97bd<br>
Author: Francois Muller <francois@concept-embarque.fr><br>
Date:   Wed Jul 13 11:07:39 2016 +0200<br>
<br>
    ineso-image-concentrator: Also set GRUB timeout to 0s<br>
<br>
 _sources/meta-inesocompany/meta-ineso/recipes-ineso/images/ineso-image-concentrator.bb | 1 +<br>
 1 file changed, 1 insertion(+)<br>
<br>
commit 72c3306af5a92a945cd0f7173c3ea40fc3c5ccd1<br>
Author: Francois Muller <francois@concept-embarque.fr><br>
Date:   Wed Jul 13 10:31:41 2016 +0200<br>
<br>
    ineso-image-concentrator: Set rootfs size to 4GB<br>
<br>
 _sources/meta-inesocompany/meta-ineso/recipes-ineso/images/ineso-image-concentrator.bb         |  6 +++++-<br>
 _sources/meta-inesocompany/meta-ineso/recipes-ineso/packagegroups/packagegroup-concentrator.bb | 19 -------------------<br>
 concentrator/conf/local.conf                                                                   |  2 +-<br>
 3 files changed, 6 insertions(+), 21 deletions(-)<br>
</body>
</html>

