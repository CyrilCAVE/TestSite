<html>
<body>
root@ServerGIT:/home/git/repositories/Ineso_StreetLight_InesoBox.git# git log --stat<br>
commit a912607d9ce7bc85ea7f09d1c20a719a6d76e3e6<br>
Author: Chritian Gossé <christian.gosse@tapko.fr><br>
Date:   Thu Dec 13 22:47:40 2012 +0100<br>
<br>
    Livraison Fabien salon HK<br>
<br>
 StreetLight.ewd | 1464 +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++<br>
 StreetLight.ewp | 3862 ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-<br>
 2 files changed, 5325 insertions(+), 1 deletion(-)<br>
<br>

commit 019887ea70323e8848c6194d655dbffe71af0314<br>
<br>

Author: Chritian Gossé <christian.gosse@tapko.fr><br>

Date:   Thu Dec 13 22:44:17 2012 +0100<br>
<br>
    Version du 03 octobre 2012<br>
<br>
 Sources/Components/Config.KnxConfig/acatConfigAppliTask.c                         |  1584 +----------<br>
 Sources/Components/Config.KnxConfig/acatConfigAppliTask.h                         |   155 -<br>
 Sources/Components/KnxChannels.0107_CH_Dimming_Actuator_Scene/acdiChannelDimmer.c |     7 +<br>
 Sources/Components/KnxChannels.0107_CH_Dimming_Actuator_Scene/acdiChannelDimmer.h |    71 +-<br>
 Sources/Components/KnxChannels.KnxAppli/apatProductAppliTask.c                    |    15 +-<br>
 Sources/Components/Stacks.KnxRfReadyStack.Common/ckalKnxApplicationLayer.c        |    29 -<br>
 Sources/Components/Stacks.KnxRfReadyStack.Common/ckpmKnxPropertiesMgt.c           |     1 -<br>
 Sources/Components/Stacks.KnxRfReadyStack.Common/cksiKnxStackInterface.h          |    18 +<br>
 Sources/Components/Stacks.KnxRfReadyStack.Common/cksiKnxStackInterface.i          |    57 +-<br>
 Sources/Components/Stacks.KnxRfReadyStack.Common/cktlKnxTransportLayer.c          |   142 +-<br>
 Sources/Components/Stacks.KnxRfReadyStack.F5324-CC1101/pcrdChipRfDriverCC1101.c   |     4 +-<br>
 Sources/ConfigDefine.h                                                            |     4 +-<br>
 Sources/ConfigTable.h                                                             |     2 -<br>
 Sources/aainApplicationInterface.c                                                |   114 +-<br>
 Sources/aainApplicationInterface.i                                                |    20 +-<br>
 Sources/ammiManMachineInterfaceTask.c                                             |    64 +-<br>
 Sources/pmcoMicroController.c                                                     |    26 +-<br>
 Sources/pmcoMicroController.h                                                     |     4 +-<br>
 StreetLight.dep                                                                   | 15612 ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++--------------------------------------<br>
 settings/StreetLight.dbgdt                                                        |    12 +-<br>
 settings/StreetLight.dni                                                          |    48 +-<br>
 settings/StreetLight.wsdt                                                         |    12 +-<br>
 22 files changed, 10084 insertions(+), 7917 deletions(-)<br>
<br>
commit 4003f12a85d239cdf4e74b3ea61e82b4dc649eff<br>
Author: Chritian Gossé <christian.gosse@tapko.fr>
Date:   Thu Dec 13 22:40:08 2012 +0100

    Initial project version

 Sources/Components/BufferManager.Cobra/sbmaBufferManager.c                                       |   459 +++
 Sources/Components/BufferManager.Cobra/sbmaBufferManager.h                                       |    82 +
 Sources/Components/Config.KnxConfig/acatConfigAppliTask.c                                        |  2323 ++++++++++++
 Sources/Components/Config.KnxConfig/acatConfigAppliTask.h                                        |   335 ++
 Sources/Components/CriticalSectionManagers.Lyre/pcsmCriticalSectionManager.c                     |   201 ++
 Sources/Components/CriticalSectionManagers.Lyre/pcsmCriticalSectionManager.h                     |    70 +
 Sources/Components/FlashManager.Ktm.Texas-msp430/pfmaFlashManager.c                              |   688 ++++
 Sources/Components/FlashManager.Ktm.Texas-msp430/pfmaFlashManager.h                              |    94 +
 Sources/Components/InterruptManagers.Jazz.Texas-msp430x5324/pitmInterruptManager-whiteled.c      |   384 ++
 Sources/Components/InterruptManagers.Jazz.Texas-msp430x5324/pitmInterruptManager.c               |   383 ++
 Sources/Components/InterruptManagers.Jazz.Texas-msp430x5324/pitmInterruptManager.h               |   170 +
 Sources/Components/KnxChannels.0107_CH_Dimming_Actuator_Scene/0107_CH_Dimming_Actuator_Scene.txt |     3 +
 Sources/Components/KnxChannels.0107_CH_Dimming_Actuator_Scene/Compile.txt                        |     8 +
 Sources/Components/KnxChannels.0107_CH_Dimming_Actuator_Scene/acdiChannelDimmer.c                |  3285 +++++++++++++++++
 Sources/Components/KnxChannels.0107_CH_Dimming_Actuator_Scene/acdiChannelDimmer.h                |   705 ++++

