 CoreApplication: Fixed race condition on client data container (ExtraData)<br>
<br>
 inc/CoreApplication.h     | 15 ++++++++++++++-<br>
 inc/fieldbus/Fieldbuses.h |  1 -<br>
 src/CoreApplication.cpp   |  9 +++++++--<br>
 src/Main.cpp              |  4 ++++<br>
 4 files changed, 25 insertions(+), 4 deletions(-)<br>
<br>
commit 2fe31d2885dcc32ec8f2bff19acc70bd5fc29c81<br>
Author: Francois Muller <francois@concept-embarque.fr><br>
Date:   Fri Jul 15 21:24:13 2016 +0200<br>
<br>
    Store: avoid risks of races<br>
<br>
 inc/Store.h   | 19 +++++++++++++++++--<br>
 src/Store.cpp | 83 ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-----------------<br>
 2 files changed, 83 insertions(+), 19 deletions(-)<br>
<br>
commit 7ff257ce83e572698f2459016fd3d7805694c727<br>
Author: Francois Muller <francois@concept-embarque.fr><br>
Date:   Fri Jul 15 18:16:56 2016 +0200<br>
<br>
    Concentrator: Set an internal limit for the number of fragments it can output when requested.<br>
<br>
 catalog.xml                                            |   1 +<br>
 inc/Concentrator.h                                     |   9 ++++++--<br>
 inc/Dictionary.h                                       |   1 +<br>
 inc/dbus/com.inesocompany.StreetLight.Concentrator.xml |   3 +++<br>
 inc/utils/PersistentContainer.h                        |  40 +++++++++++++++++++++++++++++---<br>
 src/Concentrator.cpp                                   | 162 +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++--------------------------------------<br>
 6 files changed, 164 insertions(+), 52 deletions(-)<br>

commit 3110c440b86a9aee6bb03571cd23de2d2d1bd346
Author: Francois Muller <francois@concept-embarque.fr>
Date:   Fri Jul 15 12:07:31 2016 +0200

    DBusManager: No need to unregister objects on 'NameLost' event, everything has already been already unregistered...

 src/dbus/DBusManager.cpp | 3 +--
 1 file changed, 1 insertion(+), 2 deletions(-)

commit 7d3b28fd518682f33c4122363c40f3649851395d
Author: Francois Muller <francois@concept-embarque.fr>
Date:   Thu Jul 14 09:49:32 2016 +0200

    InesoKNX: Fixed exception if Manager is destroyed but not fully initialized yet.

 src/fieldbus/inesoknx/FbInesoknxManager.cpp | 5 ++++-
 1 file changed, 4 insertions(+), 1 deletion(-)

commit 257faea098b13944d9abe4c614d5d0541378cdf1
Author: Francois Muller <francois@concept-embarque.fr>
Date:   Wed Jul 13 19:07:27 2016 +0200

    Concentrator: rise up maximum count of persistently stored status to 50k as it isn't so RAM consuming
    but better be careful not to get it all in once!

 src/Concentrator.cpp | 2 +-
root@ServerGIT:/home/git/repositories/Ineso_StreetLight_Concentrator_V3.git#
root@ServerGIT:/home/git/repositories/Ineso_StreetLight_Concentrator_V3.git# clear
root@ServerGIT:/home/git/repositories/Ineso_StreetLight_Concentrator_V3.git# ls
branches  changed, 25 insertions(+), 4 deletions(-)  config  gl-conf  HEAD  hooks  info  Muller <francois@concept-embarque.fr>  objects  refs
root@ServerGIT:/home/git/repositories/Ineso_StreetLight_Concentrator_V3.git# cd ..
root@ServerGIT:/home/git/repositories# cd Ineso_StreetLight_
Ineso_StreetLight_Concentrator.git/       Ineso_StreetLight_InesoBox.git/           Ineso_StreetLight_InesoBox_Sensor.git/    Ineso_StreetLight_Supervisor.git/
Ineso_StreetLight_Concentrator_V3.git/    Ineso_StreetLight_InesoBox_Photocell.git/ Ineso_StreetLight_Mayanet.git/
root@ServerGIT:/home/git/repositories# cd Ineso_StreetLight_InesoBox_Sensor.git/
root@ServerGIT:/home/git/repositories/Ineso_StreetLight_InesoBox_Sensor.git# git log --stat
commit f077f86cba3712ee787a12a2b3ddbace5446fe5a
Author: christiangosse <christian.gosse@me.com>
Date:   Wed May 4 13:49:57 2016 +0200

    Correct TEST_PC compiling option (after deletion of EMUL)

 868/Exe/SensorLight868_V202.hex          |   2 +-
 868/Exe/StreetLight_Sensor.d43           | Bin 541842 -> 541841 bytes
 868/List/StreetLight_Sensor.map          |   2 +-
 Aboudabhi/Exe/SensorLight433_V202.hex    |   2 +-
 Aboudabhi/Exe/StreetLight_Sensor.d43     | Bin 541842 -> 541841 bytes
 Aboudabhi/List/StreetLight_Sensor.map    |   2 +-
 SanFransisco/Exe/SensorLight915_V202.hex |   2 +-
 SanFransisco/Exe/StreetLight_Sensor.d43  | Bin 541843 -> 541842 bytes
 SanFransisco/List/StreetLight_Sensor.map |   2 +-
 Sources/aainApplicationInterface.c       |  42 ------------------------------------------
commit f077f86cba3712ee787a12a2b3ddbace5446fe5a
Author: christiangosse <christian.gosse@me.com>
Date:   Wed May 4 13:49:57 2016 +0200

    Correct TEST_PC compiling option (after deletion of EMUL)

 868/Exe/SensorLight868_V202.hex          |   2 +-
 868/Exe/StreetLight_Sensor.d43           | Bin 541842 -> 541841 bytes
 868/List/StreetLight_Sensor.map          |   2 +-
 Aboudabhi/Exe/SensorLight433_V202.hex    |   2 +-
 Aboudabhi/Exe/StreetLight_Sensor.d43     | Bin 541842 -> 541841 bytes
 Aboudabhi/List/StreetLight_Sensor.map    |   2 +-
 SanFransisco/Exe/SensorLight915_V202.hex |   2 +-
 SanFransisco/Exe/StreetLight_Sensor.d43  | Bin 541843 -> 541842 bytes
 SanFransisco/List/StreetLight_Sensor.map |   2 +-
 Sources/aainApplicationInterface.c       |  42 ------------------------------------------
 StreetLight_Sensor.dep                   |  88 ++++++++++++++++++++++++++++++++++++++++++++++------------------------------------------
 settings/StreetLight_Sensor.wsdt         |   4 ++--
 12 files changed, 54 insertions(+), 92 deletions(-)

commit a23c8196e1bcea38f3cd7973c72459103704e7b9
Author: christiangosse <christian.gosse@me.com>
Date:   Wed May 4 12:11:19 2016 +0200

    Correct call off SendOnCommand(STOP_DETECT) not well done due to misplaced #ifdef
    Remove EMUL from Project.h

 868/Exe/SensorLight868_V201.hex                                                       | 3549 ------------------------------------------------------------------------------------------------
 868/Exe/SensorLight868_V202.hex                                                       | 3550 +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 868/Exe/StreetLight_Sensor.d43                                                        |  Bin 541800 -> 541842 bytes
 868/List/StreetLight_Sensor.map                                                       | 1934 ++++++++++++++++++++++++++---------------------------
 Aboudabhi/Exe/SensorLight433_V201.hex                                                 | 3549 ------------------------------------------------------------------------------------------------
 Aboudabhi/Exe/SensorLight433_V202.hex                                                 | 3550 +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 Aboudabhi/Exe/StreetLight_Sensor.d43                                                  |  Bin 541800 -> 541842 bytes
 Aboudabhi/List/StreetLight_Sensor.map                                                 | 1934 ++++++++++++++++++++++++++---------------------------
 SanFransisco/Exe/SensorLight915_V201.hex                                              | 3549 ------------------------------------------------------------------------------------------------
 SanFransisco/Exe/SensorLight915_V202.hex                                              | 3550 +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 SanFransisco/Exe/StreetLight_Sensor.d43                                               |  Bin 541801 -> 541843 bytes
 SanFransisco/List/StreetLight_Sensor.map                                              | 1934 ++++++++++++++++++++++++++---------------------------
 Sources/Components/KnxChannels.1F00_CH_Dimming_Sensor_Scene/acdiChannelSensorDimmer.c |    5 +-
 Sources/aainApplicationInterface.c                                                    |    2 +-
 Sources/project.h                                                                     |    6 +-
 StreetLight_Sensor.dep                                                                | 2319 ++++++++++++++++++++++++++++++++-------------------------------
 StreetLight_Sensor.ewp                                                                |    6 +-
 settings/StreetLight_Sensor.dni                                                       |    4 +-
 settings/StreetLight_Sensor.wsdt                                                      |   10 +-
 19 files changed, 14733 insertions(+), 14718 deletions(-)

commit 68098fb2cdf58eb3aa88cf83c12e08f7240f5e63
Author: christiangosse <christian.gosse@me.com>
Date:   Wed Oct 14 17:05:55 2015 +0200

    Change detetction handling from Impulsion to Stable State.
    - on contact close : if (onDelay is running) stop onDelay else send ON command
    - on contact release : start onDelay
    - onDelay timeout : send off Command

    Also correct the case if Detection is running and Disable is received.

 868/Exe/SensorLight868_V200.hex                                                       | 3545 ------------------------------------------------------------------------------------------------
 868/Exe/SensorLight868_V201.hex                                                       | 3549 +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
:


