<?php
echo " <h3>lecture du fichier supervisor.html :</h3>";
    $read = file('/var/www/TestSites/Release/supervisor.html');
    foreach ($read as $line) {
        echo utf8_decode($line).'<br>';   }
?>

