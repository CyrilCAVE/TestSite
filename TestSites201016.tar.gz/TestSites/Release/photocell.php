<html>
<body>
<br>
Merge: 578d0c5 3280178<br>
Author: christiangosse <christian.gosse@me.com><br>
Date:   Wed Jun 3 16:07:55 2015 +0200<br>
<br>
    Merge branch 'master' of 192.168.2.6:ineso_lightbox_photocell<br>
<br>
commit 578d0c5f32fb3d96e4abc29d21abd3f9ef2ec3a9<br>
Author: christiangosse <christian.gosse@me.com><br>
Date:   Wed Jun 3 16:07:38 2015 +0200<br>
<br>
    Workspace Update<br>
    Output files<br>
<br>
 868/Exe/Photocell_Box_868_V200.hex   | 4367 +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-------------------------------------------------------------------------<br>
 868/Exe/StreetLight_PhotoCell.d43    |  Bin 509373 -> 509510 bytes<br>
 868/List/StreetLight_PhotoCell.map   | 2052 ++++++++++++++++++++++++++++++++++-----------------------------------<br>
 StreetLight_PhotoCell.dep            | 2194 ++++++++++++++++++++++++++++++++++++-------------------------------------<br>
 settings/StreetLight_PhotoCell.dbgdt |   24 +-<br>
 settings/StreetLight_PhotoCell.dni   |    6 +-<br>
 settings/StreetLight_PhotoCell.wsdt  |    8 +-<br>
 7 files changed, 4322 insertions(+), 4329 deletions(-)<br>
<br>
commit 32801789814b7994fe85b46afdd528c98ca4970a<br>
Author: Francois Muller <francois@concept-embarque.fr><br>
Date:   Mon Jan 5 17:45:56 2015 +0100<br>

    BugFix photocell : Use timer in continuous mode to share the code with standard ligthbox

 Sources/pmcoMicroController.c | 82 ++++++++++++++++++++++++++++++++++++++++------------------------------------------
 1 file changed, 40 insertions(+), 42 deletions(-)

commit eb2f8978b2e2913ec4371424f74d9fc57c3d43be
Author: Francois Muller <francois@concept-embarque.fr>
Date:   Sat Jan 3 21:06:51 2015 +0100

    FIX occasional spurious daylight detection !

    Photocell measurement was using a timer channel that was also used by RF chipset management !
    Now a free timer channel is used and CAPTURE mode is used to avoid critical section need.

 Sources/pmcoMicroController.c | 129 +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++------------------------------------------------------
 1 file changed, 75 insertions(+), 54 deletions(-)

commit e1b00556196777600e088fad2bce514b19fd4c8c
Author: Francois Muller <francois@concept-embarque.fr>
Date:   Thu Nov 20 15:42:33 2014 +0100

    Copy FactoryReset by BP press strategy from ineso_lightbox

 Sources/ammiManMachineInterfaceTask.c | 24 +++++++++++++-----------
 1 file changed, 13 insertions(+), 11 deletions(-)

commit a053afdc2fe605a2277c5c6cf3891ef155bb2366
Author: Francois Muller <francois@concept-embarque.fr>
Date:   Wed Nov 19 16:14:16 2014 +0100

    Only mCountTestFabBP==1 shall relaunch the timer.

 Sources/ammiManMachineInterfaceTask.c | 28 ++++++++++++++++------------
 1 file changed, 16 insertions(+), 12 deletions(-)
root@ServerGIT:/home/git/repositories/Ineso_StreetLight_InesoBox_Photocell.git# clear
root@ServerGIT:/home/git/repositories/Ineso_StreetLight_InesoBox_Photocell.git# git log --stat
commit 80ecf9ee2e5f7687172c04b1ea7d287cdfd4ff3d
Merge: 578d0c5 3280178
Author: christiangosse <christian.gosse@me.com>
Date:   Wed Jun 3 16:07:55 2015 +0200

    Merge branch 'master' of 192.168.2.6:ineso_lightbox_photocell

commit 578d0c5f32fb3d96e4abc29d21abd3f9ef2ec3a9
Author: christiangosse <christian.gosse@me.com>
Date:   Wed Jun 3 16:07:38 2015 +0200

    Workspace Update
    Output files

 868/Exe/Photocell_Box_868_V200.hex   | 4367 +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-------------------------------------------------------------------------
 868/Exe/StreetLight_PhotoCell.d43    |  Bin 509373 -> 509510 bytes
 868/List/StreetLight_PhotoCell.map   | 2052 ++++++++++++++++++++++++++++++++++-----------------------------------
 StreetLight_PhotoCell.dep            | 2194 ++++++++++++++++++++++++++++++++++++-------------------------------------
 settings/StreetLight_PhotoCell.dbgdt |   24 +-
 settings/StreetLight_PhotoCell.dni   |    6 +-
 settings/StreetLight_PhotoCell.wsdt  |    8 +-
 7 files changed, 4322 insertions(+), 4329 deletions(-)

commit 32801789814b7994fe85b46afdd528c98ca4970a
Author: Francois Muller <francois@concept-embarque.fr>
Date:   Mon Jan 5 17:45:56 2015 +0100

    BugFix photocell : Use timer in continuous mode to share the code with standard ligthbox

 Sources/pmcoMicroController.c | 82 ++++++++++++++++++++++++++++++++++++++++------------------------------------------
 1 file changed, 40 insertions(+), 42 deletions(-)

commit eb2f8978b2e2913ec4371424f74d9fc57c3d43be
Author: Francois Muller <francois@concept-embarque.fr>
Date:   Sat Jan 3 21:06:51 2015 +0100

    FIX occasional spurious daylight detection !

    Photocell measurement was using a timer channel that was also used by RF chipset management !
    Now a free timer channel is used and CAPTURE mode is used to avoid critical section need.

 Sources/pmcoMicroController.c | 129 +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++------------------------------------------------------
 1 file changed, 75 insertions(+), 54 deletions(-)

commit e1b00556196777600e088fad2bce514b19fd4c8c
Author: Francois Muller <francois@concept-embarque.fr>
Date:   Thu Nov 20 15:42:33 2014 +0100

    Copy FactoryReset by BP press strategy from ineso_lightbox

 Sources/ammiManMachineInterfaceTask.c | 24 +++++++++++++-----------
 1 file changed, 13 insertions(+), 11 deletions(-)

commit a053afdc2fe605a2277c5c6cf3891ef155bb2366
Author: Francois Muller <francois@concept-embarque.fr>
Date:   Wed Nov 19 16:14:16 2014 +0100

    Only mCountTestFabBP==1 shall relaunch the timer.

 Sources/ammiManMachineInterfaceTask.c | 28 ++++++++++++++++------------
 1 file changed, 16 insertions(+), 12 deletions(-)
 
