<?php
// Définition du chemin à explorer, garder le dernier "/"
   $homedir = "./info/";


    $dir = @opendir($homedir);
    
    while ($file = readdir($dir)) {
      		if (($file != ".") && ($file != "..")) lireFichierTxt($homedir, $file);
    }
    closedir($dir);




function lireFichierTxt($homedir, $fileTxt){
//$Fnm = "./info/info.txt"; 
$Fnm = $homedir.$fileTxt; 
if (file_exists($Fnm)) {
 $tableau = file($Fnm);
  while(list($cle,$val) = each($tableau)) {
   echo $val."<br>"."<br>";
  }
}
}
?>

