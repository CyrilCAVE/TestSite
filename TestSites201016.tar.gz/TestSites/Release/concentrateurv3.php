<html>
<body>

Date:   Fri Jul 15 21:45:12 2016 +0200<br>
<br>
    CoreApplication: Fixed race condition on client data container (ExtraData)<br>
<br>
 inc/CoreApplication.h     | 15 ++++++++++++++-<br>
 inc/fieldbus/Fieldbuses.h |  1 -<br>
 src/CoreApplication.cpp   |  9 +++++++--<br>
 src/Main.cpp              |  4 ++++<br>
 4 files changed, 25 insertions(+), 4 deletions(-)<br>
<br>
commit 2fe31d2885dcc32ec8f2bff19acc70bd5fc29c81<br>
Author: Francois Muller <francois@concept-embarque.fr><br>
Date:   Fri Jul 15 21:24:13 2016 +0200<br>
<br>
    Store: avoid risks of races<br>
<br>
 inc/Store.h   | 19 +++++++++++++++++--<br>
 src/Store.cpp | 83 ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-----------------<br>
 2 files changed, 83 insertions(+), 19 deletions(-)<br>
<br>
commit 7ff257ce83e572698f2459016fd3d7805694c727<br>
Author: Francois Muller <francois@concept-embarque.fr><br>
Date:   Fri Jul 15 18:16:56 2016 +0200<br>
<br>
    Concentrator: Set an internal limit for the number of fragments it can output when requested.<br>
<br>
 catalog.xml                                            |   1 +<br>
 inc/Concentrator.h                                     |   9 ++++++--<br>
 inc/Dictionary.h                                       |   1 +<br>
 inc/dbus/com.inesocompany.StreetLight.Concentrator.xml |   3 +++<br>
 inc/utils/PersistentContainer.h                        |  40 +++++++++++++++++++++++++++++---<br>
 src/Concentrator.cpp                                   | 162 +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++--------------------------------------<br>
 6 files changed, 164 insertions(+), 52 deletions(-)<br>
<br>
commit 3110c440b86a9aee6bb03571cd23de2d2d1bd346<br>
Author: Francois Muller <francois@concept-embarque.fr><br>
Date:   Fri Jul 15 12:07:31 2016 +0200<br>
<br>
    DBusManager: No need to unregister objects on 'NameLost' event, everything has already been already unregistered...<br>
<br>
 src/dbus/DBusManager.cpp | 3 +--<br>
 1 file changed, 1 insertion(+), 2 deletions(-)<br>

commit 7d3b28fd518682f33c4122363c40f3649851395d
Author: Francois Muller <francois@concept-embarque.fr>
Date:   Thu Jul 14 09:49:32 2016 +0200

    InesoKNX: Fixed exception if Manager is destroyed but not fully initialized yet.

 src/fieldbus/inesoknx/FbInesoknxManager.cpp | 5 ++++-
 1 file changed, 4 insertions(+), 1 deletion(-)

commit 257faea098b13944d9abe4c614d5d0541378cdf1
Author: Francois Muller <francois@concept-embarque.fr>
Date:   Wed Jul 13 19:07:27 2016 +0200

    Concentrator: rise up maximum count of persistently stored status to 50k as it isn't so RAM consuming
    but better be careful not to get it all in once!

root@ServerGIT:/home/git/repositories/Ineso_StreetLight_Concentrator_V3.git#
root@ServerGIT:/home/git/repositories/Ineso_StreetLight_Concentrator_V3.git# clear
root@ServerGIT:/home/git/repositories/Ineso_StreetLight_Concentrator_V3.git# git log --stat
commit e7afd4c4c18e4bbb9828d21e379bbf0fe693fc1b
Author: Francois Muller <francois@concept-embarque.fr>
Date:   Fri Jul 15 21:45:12 2016 +0200

    CoreApplication: Fixed race condition on client data container (ExtraData)

 inc/CoreApplication.h     | 15 ++++++++++++++-
 inc/fieldbus/Fieldbuses.h |  1 -
 src/CoreApplication.cpp   |  9 +++++++--
 src/Main.cpp              |  4 ++++
 4 files changed, 25 insertions(+), 4 deletions(-)

commit 2fe31d2885dcc32ec8f2bff19acc70bd5fc29c81
Author: Francois Muller <francois@concept-embarque.fr>
Date:   Fri Jul 15 21:24:13 2016 +0200

    Store: avoid risks of races

 inc/Store.h   | 19 +++++++++++++++++--
 src/Store.cpp | 83 ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-----------------
 2 files changed, 83 insertions(+), 19 deletions(-)

commit 7ff257ce83e572698f2459016fd3d7805694c727
Author: Francois Muller <francois@concept-embarque.fr>
Date:   Fri Jul 15 18:16:56 2016 +0200

    Concentrator: Set an internal limit for the number of fragments it can output when requested.

 catalog.xml                                            |   1 +
 inc/Concentrator.h                                     |   9 ++++++--
 inc/Dictionary.h                                       |   1 +
 inc/dbus/com.inesocompany.StreetLight.Concentrator.xml |   3 +++
 inc/utils/PersistentContainer.h                        |  40 +++++++++++++++++++++++++++++---
 src/Concentrator.cpp                                   | 162 +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++--------------------------------------
 6 files changed, 164 insertions(+), 52 deletions(-)

commit 3110c440b86a9aee6bb03571cd23de2d2d1bd346
Author: Francois Muller <francois@concept-embarque.fr>
Date:   Fri Jul 15 12:07:31 2016 +0200

    DBusManager: No need to unregister objects on 'NameLost' event, everything has already been already unregistered...

 src/dbus/DBusManager.cpp | 3 +--
 1 file changed, 1 insertion(+), 2 deletions(-)

commit 7d3b28fd518682f33c4122363c40f3649851395d
Author: Francois Muller <francois@concept-embarque.fr>
Date:   Thu Jul 14 09:49:32 2016 +0200

    InesoKNX: Fixed exception if Manager is destroyed but not fully initialized yet.

 src/fieldbus/inesoknx/FbInesoknxManager.cpp | 5 ++++-
 1 file changed, 4 insertions(+), 1 deletion(-)

commit 257faea098b13944d9abe4c614d5d0541378cdf1
Author: Francois Muller <francois@concept-embarque.fr>
Date:   Wed Jul 13 19:07:27 2016 +0200

    Concentrator: rise up maximum count of persistently stored status to 50k as it isn't so RAM consuming
    but better be careful not to get it all in once!

</body>
</html>



