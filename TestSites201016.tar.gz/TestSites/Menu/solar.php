<?php
include "http://dedicated.inesocompany.com:7670/TestSites/Menu/solarHour.php";
?>

