<!DOCTYPE html>
<html lang="en">
<head>
                <META CHARSET="UTF-8">
                <!-- css-->
		<link rel="stylesheet" type="text/css" href="TestSites/style.css">
		<base target="_parent">
</head>
<body>
	<div align="center">
		<table cellspacing=25%>
			<tr>
                                <td><form>
                                <button input type="submit"
                                        style="height:80px; width:60px;"
                                         formaction="https://www.unitag.io/fr/qrcode"
                                         title="To check with Unitag if the qrcode is correct">
                                        <img src="/TestSites/Logo/Qr_code.png" /><hr>Unitag</button>
                                </form></td>
                                <td><form>
                                <button input type="submit"
                                        style="height:80px; width:60px;"
                                         formaction="http://fr.qr-code-generator.com/"
                                         title="To check with Qr-code if the qrcode is correct">
                                        Qr_code<br><hr><img src="/TestSites/Logo/Qr_code.png" /></button>
                                </form></td>
<td><p>...<p></td>
                              <td><form>
                                <button input type="submit"
                                        style="height:100px; width:60px;"
                                        formaction="http://labelary.com/viewer.html"
                                        title="To use some ZPL aplication to create ZPL labels as Estelec">
                                        <img src="/TestSites/Logo/ZPL.png" /><hr>ZPL Viewer</button>
                               </form></td>
<td><p>...<p></td>
                              <td><form>
                                <button input type="submit"
                                        style="height:100px; width:60px;"
                                        formaction="https://www.zebra.com/us/en/support-downloads/industrial/zt410.html#downloadlistitem_9aa"
                                        title="To use some ZPL aplication to create ZPL labels as Estelec">
                                        <img src="/TestSites/Logo/ZPL.png" /><hr>ZPL Soft</button>
                                </form></td>
                              <td><form>
                                <button input type="submit"
                                        style="height:100px; width:60px;"
                                        formaction="https://chrome.google.com/webstore/detail/zpl-printer/phoidlklenidapnijkabnfdgmadlcmjo"
                                        title="To use some ZPL aplication to create ZPL labels as Estelec">
                                        <img src="/TestSites/Logo/ZPL.png" /><hr>ZPL PRINT</button>
                                </form></td>
				<td><form>
                                <button input type="submit"
                                        style="height:80px; width:60px;"
                                        formaction="/TestSites/Login/login.html"
                                        title="To come back to log">
                                        <img src="/TestSites/Logo/icone_Maya.png" /></button>
                                </form></td>
                                <td><form>
                                <button input type="submit"
                                        style="height:80px; width:60px;"
                                        formaction="http://www.google.fr"
                                        title="Let's go Google">
                                        <img src="/TestSites/Logo/google.png" /></button>
                                </form></td>
		 </tr></table>
   	</div>
</body>
</html>
