<!DOCTYPE html>
<html lang="en">
<head>
                <META CHARSET="UTF-8">
                <!-- css-->
                <link rel="stylesheet" type="text/css" href="TestSites/style.css">
		<base target="_parent">
</head>
<body>
<div align="center">
	<table cellspacing=25%>
<tr align="center" width="100">
<!--lien image pour info	<td><a href="http://dedicated.inesocompany.com:7670/testlink/login.php" target="_blank" title="Pour consulter et organiser les campagnes de test">
				<img src="/TestSites/Logo/testlink-logo.gif" /></a></td>-->
                               <td><form>
                                <button input type="submit"
                                        style="height:280px; width:280px;"
                                         formaction="/testlink/login.php"
                                         title="To consult and manage the test campaign">
                                        <img src="/TestSites/Logo/testlink-logo.gif" /></button>
                                </form></td>
                               <td><form>
                                <button input type="submit"
                                        style="height:280px; width:280px;"
                                        formaction="/bugzilla-4.5.1/index.cgi"
                                        title="To save and follow the defaults"><h2>BUGZILLA</h2><br>
                                        <img src="/TestSites/Logo/bugzilla.gif" /></button>
                                </form></td>
                               <td><form>
                                <button input type="submit"
                                        style="height:280px; width:280px;"
                                        formaction="/TestSites/Login/login.php"
                                        title="To find information about testing"><h2>MAYA TESTING</h2><br>
                                        <img src="/TestSites/Logo/logo-maya.png" /></button>
                                </form></td>
 </tr></table>
</div>
</body>
