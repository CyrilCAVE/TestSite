<!DOCTYPE html>
<html lang="en">
<head>
                <META CHARSET="UTF-8">
                <!-- css--><link rel="stylesheet" type="text/css" href="TestSites/style.css">
		<base target="_parent">
</head>

<body>
	<div align="center">
		<table cellspacing=25%>
			<tr>
                                <td><form>
                                <button input type="submit"
                                        style="height:80px; width:60px; background-color:white;"
                                         formaction="/TestSites/Specification/spec.html"
                                         title="To consult the requirements">
                                        <img src="/TestSites/Logo/specification.png"/>Spec.</button>
                                </form></td>
                               <td><form>
                                <button input type="submit"
                                        style="height:80px; width:60px; background-color:white;"
                                         formaction="/TestSites/WebSites/version.html"
                                         title="To consult the version">
                                        <img src="/TestSites/Logo/GIT_Icon.png"/>V1.4</button>
                                </form></td>
                               <td><form>
                                <button input type="submit"
                                        style="height:80px; width:60px; background-color:white;"
                                         formaction="/TestSites/WebSites/setting.html"
                                         title="To consult the network settings">
                                        <img src="/TestSites/Logo/settings.png"/>Net</button>
                                </form></td>
				<td><form>
                                <button input type="submit"
                                        style="height:80px; width:60px; background-color:white;"
                                         formaction="/TestSites/Specification/archi.html"
                                         title="To consult the test-suite">
                                        <img src="/TestSites/Logo/rchi.png"/>Test</button>
                                </form></td>
                               <td><form>
                                <button input type="submit"
                                        style="height:80px; width:60px; background-color:white;"
                                         formaction="/TestSites/Log/log.html"
                                         title="To consult the log">
                                        <img src="/TestSites/Logo/log.png"/>Log</button>
                                </form></td>
                              <td><form>
                                <button input type="submit"
                                        style="height:80px; width:60px; background-color:white; bottom:0"
                                        formaction="/TestSites/Test/testreport.html"
                                        title="To watch the test result and where is the test campaign">
                                        <img src="/TestSites/Logo/testreport.png"/>PDCA</button>
                                </form></td>
                                <td><form>
                                <button input type="submit"
                                        style="height:80px; width:60px; background-color:white;"
                                         formaction="/testlink/login.php"
                                         title="Consult and manage the test campaign">
                                        <img src="/TestSites/Logo/testlink.png"/>Suite</button>
                                </form></td>
                               <td><form>
                                <button input type="submit"
                                        style="height:80px; width:60px; background-color:white;"
                                        formaction="/bugzilla-4.5.1/index.cgi"
                                        title="To save and follow the defaults">
                                        <img src="/TestSites/Logo/bugzi.png"/>Bug</button>
                                </form></td>
                              <td><form>
                                <button input type="submit"
                                        style="height:80px; width:60px; background-color:white;"
                                         formaction="/TestSites/Map/map.html"
                                         title="Observe if the map is loading & api Map is working">
                                        <img src="/TestSites/Logo/map1.png"/>MAP</button>
                                </form></td>
                              <td><form>
                                <button input type="submit"
                                        style="height:80px; width:60px; background-color:white;"
                                         formaction="http://dedicated.inesocompany.com:2223/screens.php"
                                         title="Consult if the charge is convenient log in admin@zabbix">
                                        <img src="/TestSites/Logo/zabbix.jpg"/>Stat</button>
                                </form></td>
                                <td><form>
                                <button input type="submit"
                                        style="height:80px; width:60px; background-color:white;"
                                         formaction="/TestSites/Qrcode/label.php"
                                         title="To check if the qrcode is correct">
                                        <img src="/TestSites/Logo/Qr_code.png"/>Label</button>
                                </form></td>
                              <td><form>
                                <button input type="submit"
                                        style="height:80px; width:60px; background-color:navy; color:white; face:verdana"
                                         formaction="http://w3c.github.io/developers/tools/"
                                         title="To use some tool to check what you have done">
                                        <img src="/TestSites/Logo/w3c.png"/>Tool</button>
                                </form></td>
                               <td><form>
                                <button input type="submit"
                                        style="height:80px; width:60px; background-color:white;"
                                         formaction="https://validator.w3.org/#validate_by_uri+with_options/"
                                         title="To check the web site">
                                        <img src="/TestSites/Logo/w3c.jpg"/><br>Web</button>
                                </form></td>
                                <td><form>
                                <button input type="submit"
                                        style="height:80px; width:60px; background-color:white;"
                                        formaction="/TestSites/Chrono/chrono.php"
                                        title="To come back to log">
                                        <img src="/TestSites/Logo/chrono.png"/>Chrono</button>
                                </form></td>
                               <td><form>
                                <button input type="submit"
                                        style="height:80px; width:60px; background-color:white;"
                                        formaction="http://www.google.fr"
                                        title="Let's go Google">
                                        <img src="/TestSites/Logo/google.png"/></button>
                                </form></td>
				<td><form>
                                <button input type="submit"
                                        style="height:80px; width:60px; background-color:white;"
                                         formaction="/info.php"
                                         title="To consult the network settings">
                                        <img src="/TestSites/Logo/php.png"/>Config own site</button>
                                </form></td>
                                <td><form>
                                <button input type="submit"
                                        style="height:80px; width:60px; background-color:white;"
                                         formaction="/TestSites/changeLog.php"
                                         title="To consult the network settings">
                                        <img src="/TestSites/Logo/changeLog.png"/>Change log </button>
                                </form></td>

				<td><form>
                                <button input type="submit"
                                        style="height:80px; width:60px; background-color:white;"
                                        formaction="/TestSites/Login/login.php"
                                        title="To come back to log">
                                        <img src="/TestSites/Logo/icone_Maya.png"/></button>
                                </form></td>
			</tr>
		</table>
   	</div>
</body>

