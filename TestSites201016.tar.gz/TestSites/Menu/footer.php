<head>
<base target="_parent">
</head>

<boby>
<table width="100%" height="100%">
	<tr>
		<td><h3>Maya-Technologies :</td>
		<td>Feel free to send us a mail : <a href="mailto:cyril.cave@maya-technologies.com ; francois.nacabal@maya-technologies.com" title="Pour nous contacter si besoin">mail adresses</a></td>
		<td>Posted by : Cyril CAVÉ</h4></td>
		<td></td>
	<!--pour info simple bouton	<td><FORM><a href="" onClick="history.go(0) target="_self"><h3>Refresh</h3></FORM></td>-->
                              <td><form>
                                <button input type="submit"
                                        style="height:30px; width:80px;"
					formaction="/index.html"
                                        title="To update the page"
					>
					Refresh<br>
                                        <!--<img src="" />--></button>
                                </form></td>

	</tr>
</table>
<body>
