<?php
                        /* Calcule l'heure du lever du soleil pour Lisbonne, Portugal
                        Latitude: 38.4 North     Longitude: 9 West              Zenith ~= 90    offset: +1 GMT Seysssins 45.165612, 5.697904
                        */
                        $latitude=45.165612;$longitude=5.697904;
                        $utc=2; $zenith="90";
                        echo "Horaires du soleil à Seyssin UTC+2 : ".'<br>'."Lever : ".date("D M d Y").', sunrise time : ' .date_sunrise(time(), SUNFUNCS_RET_STRING, $latitude, -$Longitude, $zenith, $utc).'<br>';
                        echo "Coucher : ".date("D M d Y"). ', sunset time : ' .date_sunset(time(), SUNFUNCS_RET_STRING, $latitude, -9, $zenith, $utc);
                ?>

