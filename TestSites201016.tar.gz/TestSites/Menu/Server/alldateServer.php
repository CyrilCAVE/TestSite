<html>
	<?php
	// http://php.net/manual/fr/function.date.php
	// the servor date
	echo date('l jS \of F Y h:i:s A');
	// affichage :  Wednesday the 15th
		echo '<br>';
		echo date('l \t\h\e jS');
                echo '<br><br>';

	// Aujourd'hui, le 10 Mars 2001, 5:16:18 pm, Fuseau horaire 
	// Mountain Standard Time (MST)
		$today1 = date("F j, Y, g:i a");                   // March 10, 2001, 5:16 pm
		$today2 = date("m.d.y");                           // 03.10.01
		$today3 = date("j, n, Y");                         // 10, 3, 2001

		$today4 = date("Ymd");                             // 20010310
		$today5 = date('h-i-s, j-m-y, it is w Day');       // 05-16-18, 10-03-01, 1631 1618 6 Satpm01
		$today6 = date('\i\t \i\s \t\h\e jS \d\a\y.');     // It is the 10th day (10ème jour du mois).

		$today7 = date("D M j G:i:s T Y");                 // Sat Mar 10 17:16:18 MST 2001
		$today8 = date('H:m:s \m \e\s\t\ \l\e\ \m\o\i\s'); // 17:03:18 m est le mois
		$today9 = date("H:i:s");                           // 17:16:18

		$today10 = date("Y-m-d H:i:s");                    // 2001-03-10 17:16:18 (le format DATETIME de MySQL)
		$today11 = date("Y");                    // 2001-03-10 17:16:18 (le format DATETIME de MySQL)
		$today12 = date("m");                    // 2001-03-10 17:16:18 (le format DATETIME de MySQL)
		$today13 = date("d");                    // 2001-03-10 17:16:18 (le format DATETIME de MySQL)
		$today14 = date("H");                    // 2001-03-10 17:16:18 (le format DATETIME de MySQL)
		$today15 = date("i");                    // 2001-03-10 17:16:18 (le format DATETIME de MySQL)
		$today16 = date("s");                    // 2001-03-10 17:16:18 (le format DATETIME de MySQL)

	//affichage
		echo 'Template 1 : March 10, 2001, 5:16 pm : <br>'.$today1.'<br>';
		echo $today2.'<br>';
		echo $today3.'<br>'.'<br>';

		echo $today4.'<br>';
		echo $today5.'<br>';
		echo $today6.'<br>'.'<br>';

		echo $today7.'<br>';
		echo $today8.'<br>';
		echo $today9.'<br>'.'<br>';

		echo $today10.'<br>'.'<br>';

		echo ' Annee : '.$today11.'<br>';
		echo ' Mois : '.$today12.'<br>';
		echo ' Jour : '.$today13.'<br><br>';
		echo ' Heure : '.$today14.'<br>';
		echo ' Minutes : '.$today15.'<br>';
		echo ' Secondes : '.$today16.'<br><br>';

	//Timestamp
		echo 'Timestamp : <br>';
		$now  = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
		$tomorrow  = mktime(0, 0, 0, date("m")  , date("d")+1, date("Y"));
		$lastmonth = mktime(0, 0, 0, date("m")-1, date("d"),   date("Y"));
		$nextyear  = mktime(0, 0, 0, date("m"),   date("d"),   date("Y")+1);

		echo 'Now : ';
		echo $now.'<br>';
		echo 'Demain : ';
		echo $tomorrow.'<br>';
		echo 'Le mois dernier :';
		echo $lastmonth.'<br>';
		echo 'Nextyear : ';
		echo $nextyear.'<br><br>';
	//annee semaine
		echo date("YW", strtotime("2016-01-07")).'<br>'; // gives 201101
		echo date("YW", strtotime("2016-12-31")).'<br>'; // gives 201152
		echo date("YW", strtotime("2016-01-01")).'<br>'.'<br>'; // gives 201152 too
		echo date("W", strtotime("2016-01-01")).'<br>'.'<br>'; // gives 201152 too
	//annee semaine
		echo date("oW", strtotime("2016-01-07")).'<br>'; // gives 201101
		echo date("oW", strtotime("2016-12-31")).'<br>'; // gives 201152
		echo date("oW", strtotime("2016-01-01")).'<br>'.'<br>'; // gives 201052 (Year is different than previous example)
	//semaine
		echo date("W", strtotime("2016-01-01")).'<br>'.'<br>'; // gives 201052 (Year is different than previous example)
	?>
</html>
