<table>
	<tr>
		<td><img src="/TestSites/Logo/logo_ineso.gif" alt="Ineso" width="260" height="200"></td>
		<td><img src="/TestSites/Logo/logo-maya.png" alt="Ineso" width="260" height="200"></td>
	</tr>
</table>
