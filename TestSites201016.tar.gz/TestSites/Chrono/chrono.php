<!DOCTYPE html>
<html lang="en">
        <head>
                <META CHARSET="UTF-8">
                <!-- css-->
                <link rel="stylesheet" type="text/css" href="http://dedicated.inesocompany.com:7670/TestSites/style.css">
	        <title>setting.html</title>
        </head>

<body>
        <header>
            <iframe src="http://dedicated.inesocompany.com:7670/TestSites/Menu/banniere.php" width="100%" height="130" scrolling="no" frameBorder="0"></iframe>
                <h2>SETTINGS NETWORKS & TESTBENCH</h2>
        </header>


		<section>
		<p><a href="http://www.afficheip.net"
				title="Afficher votre adresse ip">
				Trouver vos réferences adresse IP via le web</a>

			Votre adresse ip est :

			<script type="text/javascript">
			var afficheip_s = "script";
			var afficheip_sc = "AfficheIP.php";
			document.write('<'+afficheip_s+' type="text/javascript"	src="http://www.afficheip.net/scripts/'+afficheip_sc+'?'+'color=000000&bg=FFFFFF&taille=12&police=Verdana"></'+afficheip_s+'>');
			</script>

		</section>



<!-- demo_worker.js -->

<!--- bouclefor 
	for(i=0;i<=10;i++)
		{
		if(i==5){
		continue;
		}
		document.write(i+"a"); -->

<br><br><br>

<!--chrono timer-tab -->
				<form><button input type="submit"
                                        style="height:80px; width:60px; background-color:white;"
                                        formaction="http://www.timer-tab.com/"
                                        title="To come back to log">
                                        <img src="/TestSites/Logo/chrono.png"/>
					Timer</button>
                                </form>
<br><br><br>

<details> <summary>setting</summary>

		<div align="center">
                      <table border="1" cellspacing="5%"  width="92%" text-align="center" style="table-layout: fixed;" >
                                       <col style="width: 10%;"/>
                                       <col style="width: 3%;"/>
                                       <col style="width: 3%;"/>
                                       <col style="width: 12%;"/>
                                       <col style="width: 6%;"/>
                                       <col style="width: 4%;"/>
                                       <col style="width: 5%;"/>
                                       <col style="width: 5%;"/>
                                       <col style="width: 5%;"/>
                                       <col style="width: 5%;"/>
                                       <col style="width: 6%;"/>
                                       <col style="width: 6%;"/>
                                       <col style="width: 10"/>
                                       <col style="width: 10%;"/>
                                       <col style="width: 5%;"/>
                                       <col style="width: 5%;"/>


				<thead>
				   <br><caption>"OVH VMWARE HYPERVISOR"</caption>
				</thead>
				<tbody>
			<tr> <td colspan="16">
				<p>dedicated.inesocompany.com:37.187.153.192 (root=60Ineso$$42)</p>
				</td> </tr>
			<tr>
				<th>Virtual Machine</th>
      				<th>Version</th>
      				<th>Status</th>
      				<th>Rôle</th>
				<th>LAN IP </th>
	                        <th>SSH PORT </th>
	                        <th>GUI PORT </th>
	                        <th>MAYANET PORT</th>
	                        <th>MQTT PORT </th>
                         	<th>DB PORT </th>
                         	<th>APIv2 PORT </th>
                         	<th>ROOT PASSWORD</th>
	                        <th>GUI PASSWORD</th>
        	                <th>MYSQL PASSWORD</th>
        	                <th>RAM Go</th>
        	                <th>Disc</th>
   			</tr>
			<tr> <th colspan="16"> PROD </th></tr>
	                <tr>
                                <th>supASolution</th>
                                <td>V2</td>
                                <td>Running</td>
                                <td>Slovakia</td>
                                <td><b>10.0.0.71</b></td>
                                <td>227</td>
                                <td>405</td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td>9819</td>
                                <td>71</td>
                                <td></td>
                                <td></td>
                                <td>1</td>
                                <td>16</td>
                        </tr>
                        <tr>
                                <th>supCL</th>
                                <td>V2</td>
                                <td>V2</td>
                                <td>Columbia</td>
                                <td>10.0.0.70</td>
                                <td>226</td>
                                <td>404</td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td>9818</td>
                                <td>70</td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                        </tr>
                        <tr>
                                <th>supDorlisheim</th>
                                <td>V2</td>
                                <td>Active</td>
                                <td>Dorlisheim</td>
                                <td>10.0.0.68</td>
                                <td>223</td>
                                <td>402</td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td>9816</td>
                                <td>68</td>
                                <td></td>
                                <td></td>
                                <td>1</td>
                                <td>16</td>
                        </tr>
                        <tr>
                                <th>supFulham</th>
                                <td>V2</td>
                                <td>transfer Bolivia</td>
                                <td>Pilote Fulham</td>
                                <td>10.0.0.67</td>
                                <td>287</td>
                                <td>401</td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td>9815</td>
                                <td>65</td>
                                <td></td>
                                <td></td>
                                <td>2</td>
                                <td>16</td>
			</tr>
                        <tr>
                                <th>supTechnilium</th>
                                <td>V2</td>
                                <td>Active</td>
                               <td>Technilium</td>
                                <td>10.0.0.89</td>
                                <td>289</td>
                                <td>8833</td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td>8834</td>
                                <td>66</td>
                                <td></td>
                                <td></td>
                                <td>1</td>
                                <td>30</td>
                        </tr>
                        <tr>
                                <th>supBOLIVIA</th>
                                <td>V3</td>
                                <td>Active</td>
                                <td>BOLIVIA</td>
                                <td>10.0.0.67</td>
                                <td>287</td>
                                <td>401</td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td>65ineso$$42</td>
                                <td>admin/admin</td>
                                <td>root/alrick</td>
                                <td></td>
                                <td></td>
                        </tr>
              <tr> <th colspan="16"> TEST </th></tr>
                        <tr>
                                <th>supDemo</th>
                                <td>V2</td>
                                <td>Active</td>
                                <td>API demo for SIRAP</td>
                                <td>10.0.0.69</td>
                                <td>224</td>
                                <td>403</td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td>9615</td>
                                <td>69</td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                        </tr>
                        <tr>
                                <th>supDemo V3</th>
                                <td>V3 1.3.13</td>
                                <td>Active</td>
                                <td>API Demo to SIRAP</td>
                                <td>10.0.0.72</td>
                                <td>229</td>
                                <td>2011</td>
                                <td>2012</td>
                                <td>2013</td>
                                <td>2014</td>
                                <td></td>
                                <td></td>
                                <td>admin/admin</td>
                                <td>root/estelec</td>
                                <td>1</td>
                                <td>16</td>
                        </tr>
                        <tr>
                                <th>supTest V3</th>
                                <td>V3 1.4.5</td>
                                <td>Active</td>
                                <td>Validation In Estelec</td>
                                <td>10.0.0.38</td>
                                <td>228</td>
                                <td>2001</td>
                                <td>2002</td>
                                <td>2003</td>
                                <td>2004</td>
                                <td></td>
                                <td>38</td>
                                <td>admin/admin</td>
                                <td>root/estelec</td>
                                <td>4</td>
                                <td>16</td>
                        </tr>
                        <tr>
                                <th>supMayaDev</th>
                                <td></td>
                                <td>Active</td>
                                <td>Tester les développements</td>
                                <td>10.0.0.10</td>
                                <td>231</td>
                                <td></td>
                                <td>12</td>
                                <td>13</td>
                                <td></td>
                                <td></td>
                                <td>10</td>
                                <td>admin/admin</td>
                                <td>root/estelec</td>
                                <td>1</td>
                                <td>16</td>
                        </tr>
                        <tr>
                                <th>supMayaTest V3</th>
                                <td>V3 1.4.6</td>
                                <td>Active</td>
                                <td>Tester les développements</td>
                                <td>10.0.0.21</td>
                                <td>321</td>
                                <td>521</td>
                                <td>522</td>
                                <td>523</td>
                                <td>524</td>
                                <td></td>
                                <td>21</td>
                                <td>admin/admin</td>
                                <td>root/estelec</td>
                                <td>4</td>
                                <td>50</td>
                        </tr>
			<tr>
				<th>supQualification V3</th>
                                <td>V3 1.4.6</td>
                                <td>Active</td>
                                <td>Qualifier les performances</td>
                                <td>10.0.0.75</td>
                                <td>232</td>
                                <td>2041</td>
                                <td>2042</td>
                                <td>2043</td>
                                <td>2044</td>
                                <td>2045</td>
                                <td>75</td>
                                <td>admin/admin</td>
                                <td>root/estelec</td>
                                <td>4</td>
                                <td>300</td>
                        </tr>
                       <tr>
                                <th>DBQualification</th>
                                <td>script</td>
                                <td>Active</td>
                                <td>Déporter les DB ressources</td>
                                <td>10.0.0.76</td>
                                <td>233</td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td>2054</td>
                                <td></td>
                                <td>76</td>
                                <td></td>
                                <td>root/estelec</td>
                                <td>8</td>
                                <td>300</td>
                        </tr>


             <tr> <th colspan="16"> NETWORK </th></tr>
                        <tr>
                                <th>FileCloud</th>
                                <td></td>
                                <td>Active</td>
                                <td>Document server</td>
                                <td>10.0.0.150</td>
                                <td>150</td>
                                <td>4000</td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td>61</td>
                                <td></td>
                                <td></td>
                        </tr>
                        <tr>
                                <th>Jenkins</th>
                                <td></td>
                                <td>Active</td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td>62</td>
                                <td></td>
                                <td></td>
                        </tr>

                        <tr>
                                <th>Routing</th>
                                <td></td>
                                <td>Active</td>
                                <td>PORT Mapping</td>
                                <td>10.0.0.1</td>
                                <td>222</td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td>63</td>
                                <td></td>
                                <td></td>
                        </tr>
                        <tr>
                                <th>VPNServ</th>
                                <td></td>
                                <td>Active</td>
                                <td>VPN SERVER</td>
                                <td>10.0.1.2</td>
                                <td>2222</td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td>67</td>
                                <td></td>
                                <td></td>
                        </tr>
           <tr> <th colspan="16"> TOOLS </th></tr>
                        <tr>
                                <th>Bugzilla / Testlink</th>
                                <td></td>
                                <td>Active</td>
                                <td>Bugtacking Test Suite & Web Pages </td>
                                <td>10.0.0.233</td>
                                <td>225</td>
                                <td>7970</td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td>70</td>
                                <td></td>
                                <td></td>
                        </tr>
                        <tr>
                                <th>GIT Server</th>
                                <td></td>
                                <td>Active</td>
                                <td>GIT SERVER</td>
                                <td>10.0.0.251</td>
                                <td>221</td>
                                <td>7669</td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td>64</td>
                                <td></td>
                                <td></td>
                        </tr>
			</tbody>
		</table>

		</div>
	</details>
      <footer><iframe src="http://dedicated.inesocompany.com:7670/TestSites/Menu/footer.php" width="100%" height="60" scrolling="no" frameBorder="0"></iframe></footer>
</body>
</html>
