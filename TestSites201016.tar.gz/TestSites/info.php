       <head>
                <META CHARSET="UTF-8">
                <!-- css-->     <link rel="stylesheet" type="text/css" href="TestSites/style.css">

	</head>
<?php
	//configuration du serveur PHP
		echo '<a href=info1.php>config PHP</a>'; 

		echo '<h3>Codage caracteres :</h3> ';
		echo mb_internal_encoding();

		echo "<h3>  Scan directory </h3>";
		echo "<p> Ici exemple de Scan de répertoires et de lecture de répertoires et des indormations de configuration de php :
			de scandir($dir) avec $dir = /var/www
			</p> ";

			$dir    = '/var/www';
			$dir1   = '/var/www/TestSites';
			$dir2   = '/var/www/TestSites/Logo';

			$files = scandir($dir);
			$files1 = scandir($dir1);
			$files2 = scandir($dir2);

echo  "<h3> Liste des Dossiers contenu dans var wwww</h3>".'<br>';
		foreach ($files as $line) { echo $line.', '; };
		echo '<br>';
		print_r($files);

echo '<br>'." Scan directory :".'<br><br>';
echo "<h3> Liste des dossiers de TestSites :</h3>".'<br>';
foreach ($files1 as $line) { echo $line.', '; };
echo '<br>';
print_r($files1);

echo " Scan directory :".'<br><br>';
echo " <h3>Liste des images du site :</h3>".'<br>';
print_r($files2);
echo '<br><br>';

echo " <h3>* Methode 1 Modification de fichier tmp.txt<h3>".'<br>';

	$file='/var/www/tmp.txt';
	$txt= "c est la méthode 1";
	file_put_contents($file,'C est gagné',FILE_APPEND);

echo '<h4><br>displaying :<br><h4>';
	$file=file(tmp.txt);
	foreach ($file as $line){echo $line.'<br>';   }

echo "<h4>display method 1 by utf8<h4>";

	$file=file("/var/www/tmp.txt");
	foreach ($file as $line){echo utf8_decode($line).'<br>';}

echo "<h4> Methode 2 Modification de fichier tmp.txt <h4>";
    $myfile = fopen($file, "w");

    $txt = "John ";
    fputs(tmp.txt, "John");
    $txt = "David";
	echo $txt.'<br>';
	echo $myfile.'<br>';
    fwrite($myfile, $txt);
    fclose($myfile);

    echo " <h3>lecture du fichier tmp :</h3>";
    $read = file('tmp.txt');
    foreach ($read as $line) { echo $line .'<br>'; }

echo '<br><br>';

echo " <h3>* lecture du fichier tree :</h3>";
    $read = file('./TestSites/tree.txt');
    foreach ($read as $line) {
        echo utf8_decode($line).'<br>';   }
	echo "######################################################################################################################";
// footer
	require '/TestSite/Menu/footer.php';
?>
